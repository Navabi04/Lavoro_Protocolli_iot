﻿namespace NetCoreClient.Sensors
{
    interface IWaterTempSensorInterface
    {
        int WaterTemperature();
    }
}
